package com.example.myapplication;

import com.android.volley.RequestQueue;

public class AppHelper {
    public static RequestQueue requestQueue;
}
